#!/sbin/sh

rm -r /data/magisk_backup_*
