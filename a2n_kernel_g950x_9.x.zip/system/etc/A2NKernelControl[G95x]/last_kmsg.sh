#!/system/bin/sh

# export last_kmsg to the emulated sdcard
cd /dev
mkdir a2n
cd a2n
cp /proc/last_kmsg last_kmsg
gzip -3 last_kmsg
cp last_kmsg.gz /storage/emulated/0/last_kmsg.zip
cd ..
rm -r a2n
