#!/system/bin/sh

LOAD=$@

# check
	if ! [ $LOAD ] ; then
		echo "Usage:"
		echo "to enable: ./ntfs.sh 1"
		echo "to disable: ./ntfs.sh 0"
		exit 1
	fi

# unload modules
	if [ $LOAD = 0 ] ; then
		# enable wakelock
		echo ntfs0 > /sys/power/wake_lock

		rmmod ntfs

		# disable wakelock
		echo ntfs0 > /sys/power/wake_unlock

		exit 0
	fi

# load modules
	if [ $LOAD = 1 ] ; then
		# enable wakelock
		echo ntfs1 > /sys/power/wake_lock

		insmod /system/lib/modules/ntfs.ko

		# disable wakelock
		echo ntfs1 > /sys/power/wake_unlock
	fi
