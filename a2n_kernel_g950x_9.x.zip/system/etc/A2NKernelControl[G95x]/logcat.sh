#!/system/bin/sh

# export logcat & dmesg to the emulated sdcard
cd /dev
mkdir a2n
cd a2n
logcat -d > logcat
dmesg > dmesg
gzip -3 logcat dmesg
cp logcat.gz /storage/emulated/0/logcat.zip
cp dmesg.gz /storage/emulated/0/dmesg.zip
cd ..
rm -r a2n
