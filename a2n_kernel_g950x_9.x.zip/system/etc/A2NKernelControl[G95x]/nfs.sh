#!/system/bin/sh

LOAD=$@

# check
	if ! [ $LOAD ] ; then
		echo "Usage:"
		echo "to enable: ./nfs.sh 1"
		echo "to disable: ./nfs.sh 0"
		exit 1
	fi

# unload modules
	if [ $LOAD = 0 ] ; then
		# enable wakelock
		echo nfs0 > /sys/power/wake_lock

		rmmod nfsv4
		rmmod nfsv3
		rmmod nfsv2
		rmmod nfs
		rmmod auth_rpcgss
		rmmod oid_registry
		rmmod lockd
		rmmod grace
		rmmod dns_resolver
		rmmod sunrpc
		rmmod fscache

		# disable wakelock
		echo nfs0 > /sys/power/wake_unlock

		exit 0
	fi

# load modules
	if [ $LOAD = 1 ] ; then
		# enable wakelock
		echo nfs1 > /sys/power/wake_lock

		insmod /system/lib/modules/fscache.ko
		insmod /system/lib/modules/sunrpc.ko
		insmod /system/lib/modules/dns_resolver.ko
		insmod /system/lib/modules/grace.ko
		insmod /system/lib/modules/lockd.ko
		insmod /system/lib/modules/oid_registry.ko
		insmod /system/lib/modules/auth_rpcgss.ko
		insmod /system/lib/modules/nfs.ko
		insmod /system/lib/modules/nfsv2.ko
		insmod /system/lib/modules/nfsv3.ko
		insmod /system/lib/modules/nfsv4.ko

		# disable wakelock
		echo nfs1 > /sys/power/wake_unlock
	fi
