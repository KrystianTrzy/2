#!/system/bin/sh

LOAD=$@

# check
	if ! [ $LOAD ] ; then
		echo "Usage:"
		echo "to enable: ./cifs.sh 1"
		echo "to disable: ./cifs.sh 0"
		exit 1
	fi

# unload modules
	if [ $LOAD = 0 ] ; then
		# enable wakelock
		echo cifs0 > /sys/power/wake_lock

		rmmod cifs
		rmmod md4
		rmmod dns_resolver
		rmmod fscache

		# disable wakelock
		echo cifs0 > /sys/power/wake_unlock

		exit 0
	fi

# load modules
	if [ $LOAD = 1 ] ; then
		# enable wakelock
		echo cifs1 > /sys/power/wake_lock

		insmod /system/lib/modules/fscache.ko
		insmod /system/lib/modules/dns_resolver.ko
		insmod /system/lib/modules/md4.ko
		insmod /system/lib/modules/cifs.ko

		# disable wakelock
		echo cifs1 > /sys/power/wake_unlock
	fi
