#!/system/bin/sh

echo $$ > /dev/cpuset/system-background/tasks

RAM_PERCENT=$@
MAX=100
PAGE_CLUSTER=0
MAX_THREADS=8
MIN_FREE_KB=8192
GAP_KB=4096

# check
	if ! [ $RAM_PERCENT ] ; then
		echo "Usage:"
		echo "to enable: ./zram.sh ram_percent_value"
		echo "to disable: ./zram.sh 0"
		exit 1
	fi

	if [ $RAM_PERCENT -gt $MAX ] ; then
		echo "Error: out of range: max $MAX percent."
		exit 1
	fi

# reset zram if it's already running
	if [ -d /sys/block/zram0 ] ; then
		DISKSIZE=$(cat /sys/block/zram0/disksize)
		if ! [ $DISKSIZE = 0 ] ; then
			# enable wakelock
			echo zram0 > /sys/power/wake_lock
  
			echo 3 > /proc/sys/vm/page-cluster

			# swapoff
			swapoff /dev/block/zram0
			wait $!

			# reset device
			echo 1 > /sys/block/zram0/reset

			# disable wakelock
			echo zram0 > /sys/power/wake_unlock
		fi

		if [ $RAM_PERCENT = 0 ] ; then
			exit 0
		fi

	fi

# enable wakelock
	echo zram1 > /sys/power/wake_lock

# load modules
	if ! [ -d /sys/block/zram0 ] ; then
		insmod /system/lib/modules/zsmalloc.ko
		insmod /system/lib/modules/lz4_compress.ko
		insmod /system/lib/modules/lz4_decompress.ko
		insmod /system/lib/modules/lz4.ko
		insmod /system/lib/modules/zram.ko
	fi
	wait $!
	if ! [ -d /sys/block/zram0 ] ; then
		echo "Error: zRam driver is missing !"
		echo zram1 > /sys/power/wake_unlock
		exit 1
	fi

# enable zram
	TOTAL_RAM_KB=`cat /proc/meminfo | grep -e "^MemTotal:" | sed -e 's/^MemTotal: *//' -e 's/  *.*//'`
	CMA_KB=`cat /proc/meminfo | grep -e "^CmaTotal:" | sed -e 's/^CmaTotal: *//' -e 's/  *.*//'`
	RBIN_KB=`cat /proc/meminfo | grep -e "^RbinTotal:" | sed -e 's/^RbinTotal: *//' -e 's/  *.*//'`
	RAM_KB=$((TOTAL_RAM_KB - MIN_FREE_KB - CMA_KB - RBIN_KB - GAP_KB))
	SIZE=$((RAM_KB * RAM_PERCENT / 100))
	echo $PAGE_CLUSTER > /proc/sys/vm/page-cluster
	echo 0 > /sys/block/zram0/queue/read_ahead_kb
	echo $MAX_THREADS > /sys/block/zram0/max_comp_streams
	echo "$((SIZE))K" > /sys/block/zram0/disksize
	mkswap /dev/block/zram0
	swapon -p 0 /dev/block/zram0

# disable wakelock
	echo zram1 > /sys/power/wake_unlock
