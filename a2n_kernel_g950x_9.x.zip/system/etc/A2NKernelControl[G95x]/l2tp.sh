#!/system/bin/sh

LOAD=$@

# check
	if ! [ $LOAD ] ; then
		echo "Usage:"
		echo "to enable: ./l2tp.sh 1"
		echo "to disable: ./l2tp.sh 0"
		exit 1
	fi

# unload modules
	if [ $LOAD = 0 ] ; then
		# enable wakelock
		echo l2tp0 > /sys/power/wake_lock

		rmmod l2tp_core.ko
		rmmod ip6_udp_tunnel.ko
		rmmod udp_tunnel.ko

		# disable wakelock
		echo l2tp0 > /sys/power/wake_unlock

		exit 0
	fi

# load modules
	if [ $LOAD = 1 ] ; then
		# enable wakelock
		echo l2tp1 > /sys/power/wake_lock

		insmod /system/lib/modules/udp_tunnel.ko
		insmod /system/lib/modules/ip6_udp_tunnel.ko
		insmod /system/lib/modules/l2tp_core.ko

		# disable wakelock
		echo l2tp1 > /sys/power/wake_unlock
	fi
